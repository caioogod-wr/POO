package atv1.questao3;

public class Termo {
    //cada termo tem um grau e um coeficiente
    private int grau;
    private int coeficiente;
    
    //cria o termo com o grau recebido e com coeficiente 0
    public Termo(int pGrau){
        grau = pGrau;
        coeficiente = 0;
    }
    
    //modifica o coeficiente de um termo ja criado
    public void setTermoCoeficiente(int coeficiente){
        this.coeficiente = coeficiente;
    }
    
    //retorna o grau de um termo
    public int getGrau(){
        return grau;
    }
    
    //retorna o coeficiente de um termo
    public int getCoeficiente(){
        return coeficiente;
    }
    
    //soma o coeficiente de um termo recebido ao coeficiente do termo em questao
    public void somaCoeficiente(int coeficiente){
        this.coeficiente += coeficiente;
    }
    
    //imprime o termo
    public void imprimeTermo(){
        System.out.print(coeficiente + "x^" + grau);
    }
    
    //retorna o resultado do termo substituindo x pelo valor recebido 
    public int resultadoTermo(int x){
        int produto = 1;
        for(int i = 0; i < grau; i++){
            produto = produto * x;
        }
        return coeficiente * produto;
    }
}