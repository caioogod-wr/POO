/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package questao2servidor;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.util.ArrayList;

/**
 *
 * @author 12547785
 */


public class ThreadLeTeclado implements Runnable {
    ServerSocket Ouvido;
    ArrayList<String> mensagens;
    
    ThreadLeTeclado(ServerSocket novoOuvido, ArrayList<String> mens) {
        Ouvido = novoOuvido;
        mensagens = mens;
    }
    
    @Override
    public void run() {
        BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in)); //LEITOR DE MENSAGENS DO TECLADO
        
        String lido;
        try {
            while (true) {
                lido = teclado.readLine(); // LE UMA LINHA DO TECLADO
                mensagens.add(lido); // ADICIONA MENSAGEM NO ARRAYLIST
                if (lido.equals("Desligar")) {
                    Thread.sleep(2000); // AGUARDA MENSAGEM DE SAIDA SER ENVIADA AOS 
                    Ouvido.close();
                    System.exit(0);
                }
            }
        } catch(IOException | InterruptedException e) {
            System.exit(1); //ERRO
        }
    }
}

