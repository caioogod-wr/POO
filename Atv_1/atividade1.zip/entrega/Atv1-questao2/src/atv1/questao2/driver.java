package atv1.questao2;

public class driver{
    public boolean ligado; //variavel que define se o dispositivo esta ligado ou nao

    public driver(){
        ligado = false;
    }

    //funcoes comuns aos diferentes tipos de drivers
    public void ligaDispositivo(){ //liga o dispositivo
        ligado = true;
    }
    public void verificaStatus(){ //imprime se o dispositivo esta ligado ou nao
        if(ligado == true){
            System.out.println("Status: Ligado");
            return;
        }
        System.out.println("Status: Desligado");
    }
  
    public boolean executaTeste(){ //verifica se o dispositivo esta ligado e retorna um booleano
        return ligado;
    }
}