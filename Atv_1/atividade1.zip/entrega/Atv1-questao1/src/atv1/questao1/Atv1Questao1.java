package atv1.questao1;

public class Atv1Questao1 {
    public static void main(String[] args) {
        //cria um celular com a frequencia do processador de 90
        celular c = new celular(90);
        c.coloca_fone();
        c.liga_tela();
    }
}
