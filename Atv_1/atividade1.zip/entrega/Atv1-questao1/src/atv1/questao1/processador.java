package atv1.questao1;

public class processador {
    public int frequencia;
    private int num_nucleos;

    //cria o processador
    public processador(int frequencia){
        this.frequencia = frequencia;
        num_nucleos = 4;
    } 
    
    //muda a frequencia
    public void setFrequencia(int pFreq) {
        frequencia = pFreq;
    }

    //retorna a frequencia
    public int getFrequencia() {
        return frequencia;
    }

    //muda o numeoro de nucleos
    public void setNum_nucleos(int pNum) {
        num_nucleos = pNum;
    }

    //retoan o numero de nucleos
    public int getNum_nucleos() {
        return num_nucleos;
    }

}
