package atv1.questao1;

public class sistema_de_som {
    public int volume;
    private String dispositivo_saida;

    public sistema_de_som(String dispositivo_saida){
        volume = 10;
        this.dispositivo_saida = dispositivo_saida;
    }
    
    //muda o volume
    private void setVolume(int pVol) {
        volume = pVol;
    }

    //muda o volume para 0 (muta)
    public void mutar() {
        setVolume(0);
    }

    //retorna o volume
    public int getVolume() {
        return volume;
    }

    //muda o dispositivo de saida
    public void setDispositivo_saida(String pDisp) {
        dispositivo_saida = pDisp;
    }

    //retona o dispositivo de saida
    public String getDispositivo_saida() {
        return dispositivo_saida;
    }
}