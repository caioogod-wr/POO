/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package questao2servidor;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

/**
 *
 * @author 12547785
 */

public class ThreadEnviaCliente implements Runnable {
    Socket Cliente;
    ArrayList<String> mensagens;
    String enviado = "";
    String aEnviar = "";
    
    ThreadEnviaCliente(Socket novoCliente, ArrayList<String> mens) {
        Cliente = novoCliente;
        mensagens = mens;
    }
    
    @Override
    public void run() {
        try {
            PrintWriter Envia = new PrintWriter(new OutputStreamWriter(Cliente.getOutputStream())); // IMPRIME AO CLIENTE
            while (true) {
                aEnviar = mensagens.get(mensagens.size() - 1); // RECEBE ULTIMA MENSAGEM
                if ( !(aEnviar.equals("") || aEnviar.equals(enviado))) {
                    Envia.println(aEnviar); //IMPRIME MENSAGEM AO CLIENTE
                    Envia.flush();
                    enviado = aEnviar;
                }
                
                if (enviado.equals("Desligar")) { // PROCESSO DE DESLIGAMENTO DO SERVIDOR
                    Envia.close();
                }
                
                Thread.sleep(1000); // AGUARDA NOVAS MENSAGENS
            }
        } catch(IOException | InterruptedException e) {
            System.exit(1); //ERRO
        }
    }
}

