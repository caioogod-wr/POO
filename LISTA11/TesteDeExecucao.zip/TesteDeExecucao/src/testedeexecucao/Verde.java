/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package testedeexecucao;

import java.io.Serializable;

/**
 *
 * @author 12547785
 */
public class Verde implements Executavel,Serializable{
    private int numCor;
    private String nome;

    Verde(int num,String nome){
        numCor = num;
        this.nome = nome;
    }
    public void fazer(){
        System.out.println("Retirando o nome da cor...");
        nome = "Anonimo";
        System.out.println("Novo nome da cor: "+ nome);
    }
    public String getNome(){
        return nome;
    }
    public int getNumCor(){
        return numCor;
    }
    
}
