/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   pilha.h
 * Author: Felipe Cecato
 *
 * Created on 03 de Janeiro de 2023, 09:53
 */


#ifndef PILHA_H
#define PILHA_H

#include <iostream> 
#include <deque> 

using namespace std;

template <class T, class D = deque<T>>
class pilha {
private:
    D *d;
    int tam;
public:
    pilha(int tam) {
        d = new D(); // CRIA A PILHA ADAPTADA
        this->tam = tam;
    }
    
    virtual ~pilha() {
        delete d; // LIBERAR A MEMORIA
    };
    
    void push(const T &valor);
    void pop();
    T getTopo();
    int getTamanho();
    int getTamanhoMax();
};


template <class T, class D>
int pilha<T,D> :: getTamanho() {
    return d->size(); // retorna o tamanho atual
}

template <class T, class D>
int pilha<T,D> :: getTamanhoMax() {
    return tam; // retorna o tamanho maximo
}


template <class T,  class D>
void pilha<T, D>::push(const T &valor) {
    if (getTamanho() == tam)
    {
        cout<<"Pilha cheia"<<endl;
        exit(-1);
    }
    cout << "Adicionando o elemento " << valor << endl;
    d->push_back(valor);
}


template <class T, class D> 
void pilha<T,D>::pop() {
    if (getTamanho() == 0){
        cout<<"Pilha vazia"<<endl;
        exit(-1);
    }
    cout<<"Removendo o elemento " << d->back() << endl;
    d->pop_back(); // remove elemento no container

}


template <class T, class D>
T pilha<T,D>::getTopo() {
    if (getTamanho() == 0){
        cout<<"Pilha vazia"<<endl;
        exit(-1);
    }
    return d->back(); // retorna elemento
}


#endif /* PILHA_H */
