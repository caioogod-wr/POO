/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package testedeexecucao;

import java.io.Serializable;

/**
 *
 * @author 12547785
 */
public class Azul implements Executavel,Serializable{
    private int numCor;
    private String nome;
    private int numFavorito;

    Azul(int num,int num2,String nome){
        numCor = num;
        this.nome = nome;
        numFavorito = num2;
    }
    public void fazer(){
        System.out.println("Aumentando o numero da cor...");
        numCor = numCor +100;
        System.out.println("O novo numero da cor eh: "+ numCor);

    }
    public String getNome(){
        return nome;
    }
    public int getNumFavorito(){
        return numFavorito;
    }

    public int getNumCor(){
        return numCor;
    }

}
