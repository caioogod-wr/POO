/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package testedeexecucao;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author 12547785
 */
public class Servidor extends TesteDeExecucao {
     /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
       try {
            ServerSocket Ouvido = new ServerSocket(8008);
            Socket ServidorSocket = Ouvido.accept();

            ObjectInputStream ReceberObjeto = new ObjectInputStream(ServidorSocket.getInputStream());

            PrintWriter Enviar = new PrintWriter(new OutputStreamWriter(ServidorSocket.getOutputStream()));
            Object o;
            do {
              o = ReceberObjeto.readObject();
              
              if (o instanceof Azul) {
                Azul t = (Azul) o;
                Enviar.println("Recebido um objeto azul chamado " + t.getNome());
              }
              else
                if (o instanceof Verde) {
                    Verde q = (Verde) o;
                    Enviar.println("Recebido um objeto verde chamado" + q.getNome());
                }
              fazer();
              Enviar.flush();
            } while(o != null);

            ReceberObjeto.close();
            Enviar.close();
            ServidorSocket.close();
            Ouvido.close();
        } catch (IOException e) {
            System.out.println("Erro de IOException: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("Erro de ClassNotFound: " + e.getMessage());
        }
    }
 }
    

