package atv1.questao2;

public class driver_impressao extends driver {
    
    driver_impressao(){ //construtor
        super();
    }
  
    public void imprimePaginas(){    //imprime uma mensagem que simula a impressao de uma pagina 
        verificaStatus();
        if(executaTeste()){
            System.out.println("Aguarde o final do processo...");
            System.out.println("Imprimindo...");
            System.out.println("...");   
            System.out.println("Finalizado");   
            return;
        }
        System.out.println("Erro"); 
  } 
}
