package atv1.questao2;

import java.util.*;

public class driver_video extends driver {
    public int brilho; //variavel que representa o nivel de brilho

    driver_video() { //construtor
        super(); 
        brilho = 100;// definir nivel padrao
    }

    public void alteraBrilhoDeExibicao() { //recebe um valor do usuario e altera o valor da variavel 'brilho'
        verificaStatus();
        if (executaTeste()) {
            System.out.println("Digite o nivel de brilho: ");
            Scanner s = new Scanner(System.in);
            brilho = s.nextInt();
            s.close();
            return;
        }
        System.out.println("Erro");
    }
}
