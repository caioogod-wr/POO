package atv1.questao2;

public class sistema_operacional{ //cada sistema operacional tem um driver de cada operacao
    public driver_impressao imp;
    public driver_video vid;
    public driver_rede red;

    public sistema_operacional(){ //construtor
        imp = new driver_impressao();
        red = new driver_rede();
        vid = new driver_video();
    }
}
