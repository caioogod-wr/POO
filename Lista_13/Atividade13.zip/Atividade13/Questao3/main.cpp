/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Felipe Cecato
 *
 * Created on 03 de Janeiro de 2023, 09:53
 */

#include "pilha.h" // pilha, cout, deque, runtime_error
#include <vector> // vector
#include <string> // string

/*
 * 
 */
int main(int argc, char** argv) {
    pilha<int> *p = new pilha<int>(5); // pilha adaptada de inteiros

        // exemplo de inteiros
        p->push(1);
        p->push(2);
        p->push(3);
        p->push(4);
        p->push(5);
        //p->push(6); // forcar pilha cheia
        
        for(int i = 0; i < p->getTamanhoMax();i++){
            p->pop();
        }
        //p->pop(); // forcar pilha vazia
        
    // apaga a pilha
    delete p;
    return 0;
}



