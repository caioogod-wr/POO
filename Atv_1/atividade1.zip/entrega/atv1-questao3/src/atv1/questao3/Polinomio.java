package atv1.questao3;
import java.util.ArrayList;

public class Polinomio {
    //cada polinomio possui uma lista de termos e um grau maximo que um termo pode ocupar
    private ArrayList<Termo> termos;
    private int grauMax;
    
    //construtor de polinomio recebe um grau maximo e, então cria uma lista com todos os possiveis termos
    public Polinomio(int pGrauMax){
        grauMax = pGrauMax;
        termos = new ArrayList<Termo>();
        for(int i = 0; i <= grauMax; i++){
            Termo t = new Termo(i);
            termos.add(i, t);
        }
    }
    
    //funcao que soma um termo ao polinomio
    public void Add(Termo termo){
        if(termo.getGrau() > grauMax){
            //grau do termo recebido pela funcao eh maior que o grau do polinomio
            System.out.println("Grau maior que o máximo");
            return;
        }
        //na lista de termos, o ".get" procura o termo com grau igual ao que sera adicionado
        //depois, ele soma o coeficiente do termo adicionado ao termo ja existente no polinomio
        termos.get(termo.getGrau()).somaCoeficiente(termo.getCoeficiente());
    }
    
    //imprime na tela o polinomio
    public void Mostra(){
        System.out.print("y = ");
        for(int i = 0; i <= grauMax; i++){
            termos.get(i).imprimeTermo();
            if(i < grauMax)
                System.out.print(" + ");
        }
        System.out.println();
    }
    
    //recebe x e retorna o valor da expressao
    public int Calcula(int x){
        int soma = 0;
        for(int i = 0; i <= grauMax; i++){
            soma += termos.get(i).resultadoTermo(x);
        }
        return soma;
    }
}
