/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package arraydeque;

import arraylist.objeto;
import java.util.ArrayDeque;
import java.util.Random;

/**
 *
 * @author Felipe
 */
public class arraydeque {
    
    public static void main(String[] args) {
        long tempoInicial;
        double tempoTotal = 0;
        ArrayDeque < objeto > a;
        a = new ArrayDeque<>();
        objeto o = new objeto(1);
        Random gerador = new Random(System.currentTimeMillis());
       
        long tamanho = (int) Math.pow(10, 7);
        
        tamanho*=1;
        
        tempoInicial = System.currentTimeMillis();
        
        for(long i = 0; i < tamanho; i++)
        {
            a.add(new objeto(gerador.nextDouble()));//ADICIOAR ELEMENTOS
            
        }
        
        for(int i = 0 ; i < tamanho/2;i++){
            o = a.getFirst();//BUSCA E REMOCAO
            a.removeFirst();
        }
        
        
        for(int i  =0 ; i < tamanho/2;i++){
            a.removeFirst();//REMOVER ELEMENTOS RESTANTES
        }
        
        
        //IMPRIMIR TEMPO TOTAL
        tempoTotal= tempoTotal + (System.currentTimeMillis() - tempoInicial) / 1000.0;
        System.out.println(tempoTotal);
        
    }
    
}
//1*10 a 7 = 06.038
//2*10 a 7 = 12.757
//3*10 a 7 = 14.439
//4*10 a 7 = 28.869
