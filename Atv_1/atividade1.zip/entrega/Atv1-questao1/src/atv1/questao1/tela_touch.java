package atv1.questao1;

public class tela_touch {
    public boolean ligada;
    private int brilho;
    
    //cria a tela com o brilho em 10 e desligada
    public tela_touch(){
        brilho = 10;
        ligada = false;
    }

    //liga ou desliga a tela
    private void setLigada(boolean pLigada) {
        ligada = pLigada;
    }

    //desliga a tela por inatividade
    public void desliga_inatividade() {
        setLigada(false);
    }

    //retorna de a tela esta desligada ou nao
    public boolean getLigada() {
        return ligada;
    }

    //muda o brilho
    public void setBrilho(int pBrilho) {
        brilho = pBrilho;
    }

    //retorna o valor do brilho
    public int getBrilho() {
        return brilho;
    }
}
