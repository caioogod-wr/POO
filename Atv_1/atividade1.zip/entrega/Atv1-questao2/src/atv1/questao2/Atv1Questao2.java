package atv1.questao2;

public class Atv1Questao2 {
    public static void main(String[] args) {
        sistema_operacional v = new sistema_operacional();
        v.imp.ligaDispositivo(); //verificacao de funcionamento do driver de impressao
        v.imp.imprimePaginas();
        System.out.println();
    
        v.vid.ligaDispositivo(); //verificacao de funcionamento do driver de video
        v.vid.alteraBrilhoDeExibicao();
        System.out.println("O nivel de brilho eh: " + v.vid.brilho);
        System.out.println();

        v.red.ligaDispositivo(); //verificacao de funcionamento do driver de rede
        v.red.enviaPacoteDeDados();
        System.out.println();
    }
    
}
