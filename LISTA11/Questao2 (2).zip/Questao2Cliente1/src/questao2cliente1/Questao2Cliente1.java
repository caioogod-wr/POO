/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package questao2cliente1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

/**
 *
 * @author 12547785
 */
public class Questao2Cliente1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {        
        try{
            Socket Cliente = new Socket("localhost",8090);
            BufferedReader Recebimento = new BufferedReader(new InputStreamReader(Cliente.getInputStream()));
            String conteudo_recebido;
            do{ 
                conteudo_recebido = Recebimento.readLine();
                System.out.println("O servidor disse:" + conteudo_recebido);
      
            }while(conteudo_recebido.compareTo("Desligar")!= 0);
            Recebimento.close();
            Cliente.close();

        }catch(IOException e){
            System.out.println("Erro: " + e.getMessage());
        }   
    }
    
}
