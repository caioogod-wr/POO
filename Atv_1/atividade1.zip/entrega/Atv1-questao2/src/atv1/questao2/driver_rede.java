package atv1.questao2;

public class driver_rede extends driver {
    driver_rede(){ //construtor
        super();
    }
  
    public void enviaPacoteDeDados(){ //imprime uma mensagem que simula o envio de um pacote 
        System.out.println("Enviando pacote...");
        System.out.println("...");
        System.out.println("Pacote enviado");
    }
}
