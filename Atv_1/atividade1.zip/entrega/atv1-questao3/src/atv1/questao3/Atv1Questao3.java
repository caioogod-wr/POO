package atv1.questao3;

public class Atv1Questao3 {
    public static void main(String[] args) {
        
        //cria e mostra um polinomio "p" de grau 5 (6 termos)
        Polinomio p = new Polinomio(5);
        p.Mostra();
        
        //cria um termo "t1" de grau 2
        Termo t1 = new Termo(2);
        //modifica o coeficiente do termo para 5
        t1.setTermoCoeficiente(5);
        
        //adiciona o termo no polinomio "p" e mostra "p" novamente
        p.Add(t1);
        p.Mostra();
        
        //imprime o calculo de "p" para x = 3
        System.out.println(p.Calcula(3));
    }
    
}