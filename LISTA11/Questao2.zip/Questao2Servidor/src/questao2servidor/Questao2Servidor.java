/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package questao2servidor;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

/**
 *
 * @author 12547785
 */
public class Questao2Servidor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<String> mensagens = new ArrayList(); 
                                                        
        mensagens.add("");
        
        try {
            ServerSocket Ouvido = new ServerSocket(8090);
            
            // LEITURA DO TECLADO
            Thread THREAD_LEITURA = new Thread(new ThreadLeTeclado(Ouvido, mensagens));
            THREAD_LEITURA.start();
            
            // ACEITAR MAIS DE UM CLIENTE
            while(true) {
                Socket Cliente = Ouvido.accept(); // ACEITA NOVO CLIENTE
                Thread THREAD_CLIENTE = new Thread(new ThreadEnviaCliente(Cliente, mensagens));//CRIA NOVA THEAD
                THREAD_CLIENTE.start();//EXECUTA THREAD DE ENVIO DE INFORMACOES
            }
            
        } catch(IOException e) {
            System.exit(1); // ERRO
        }
        
    }
}