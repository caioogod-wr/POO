/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arraylist;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Felipe
 */
public class arraylist {
    
    public static void main(String[] args) {
        long tempoInicial;
        double tempoTotal = 0;
        ArrayList < objeto > a;
        a = new ArrayList<>();
        objeto o = new objeto(1);
        Random gerador = new Random(System.currentTimeMillis());
       
        //TAMANHO
        long tamanho = (int) Math.pow(10, 5);
        tamanho*= 6;
        
        
        //SETAR TEMPO INICIAL
        tempoInicial = System.currentTimeMillis();
        
        
        for(long i = 0; i < tamanho; i++)
        {
            a.add(new objeto(gerador.nextDouble()));//ACICIONAR ELEMENTOS
            
        }
        
        for(int i = 0 ; i < tamanho/2;i++){
            o = a.get(i);//BUSCAR
        }
        
        
        for(int i  = 0 ; i < tamanho;i++){
            a.remove(0);//REMOVER
        }
        
        
        
        tempoTotal= tempoTotal + (System.currentTimeMillis() - tempoInicial) / 1000.0;
        //IMPRIMIR TEMPO TOTAL
        System.out.println(tempoTotal);
        
    }
    
}
//6* 10 a 5 = 23.864
//8* 10 a 5 = 43.196
//10 a 6 = 77.227