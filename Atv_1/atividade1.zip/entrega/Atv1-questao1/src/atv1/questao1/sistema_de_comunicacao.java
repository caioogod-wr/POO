package atv1.questao1;

public class sistema_de_comunicacao {
    public double frequencia_internet;
    private boolean conectado;

    public sistema_de_comunicacao(){
        frequencia_internet = 97.3;
        conectado = false;
    }
    
    //muda a fequencia
    private void setFrequencia(double pFreq) {
        frequencia_internet = pFreq;
    }

    //muda a frequencia para a padrao
    public void define_frequencia_padrao() {
        setFrequencia(97.3);
    }

    //retorna a frequencia
    public double getFrequenciaInternet() {
        return frequencia_internet;
    }

    //conecta o dispositivo
    public void setConectado(boolean pBool) {
        conectado = pBool;
    }
    
    //terona se esta conectado ou nao
    public boolean getConectadao() {
        return conectado;
    }
}
