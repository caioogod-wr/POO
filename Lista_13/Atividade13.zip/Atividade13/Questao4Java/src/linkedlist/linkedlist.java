/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package linkedlist;

import java.util.LinkedList;
import java.util.Random;

/**
 *
 * @author Felipe
 */
public class linkedlist {
    
    public static void main(String[] args) {
        long tempoInicial;
        double tempoTotal = 0;
        LinkedList < objeto > a;
        a = new LinkedList<>();
        objeto o = new objeto(1);
        Random gerador = new Random(System.currentTimeMillis());
       
        
        //TAMANHO
        long tamanho = (int) Math.pow(10, 5);
        tamanho*=4;
        
        //SETAR TEMPO INICIAL
        tempoInicial = System.currentTimeMillis();
        
        
        for(long i = 0; i < tamanho; i++)
        {
            a.add(new objeto(gerador.nextDouble()));//INSERIR ELEMENTOS
            
        }
        
        for(int i = 0 ; i < tamanho/2;i++){
            o = a.get(i);//BUSCAR
        }
        
        
        for(int i  =0 ; i < tamanho;i++){
            a.remove(0);//REMOVER
        }
        
        
        //IMPRIMIR TEMPO TOTAL
        tempoTotal= tempoTotal + (System.currentTimeMillis() - tempoInicial) / 1000.0;
        System.out.println(tempoTotal);
        
    }
    
}
//2* 10 a 5 = 7.82 
//3* 10 a 5 = 34.594
//4* 10 a 5 = 73.255
