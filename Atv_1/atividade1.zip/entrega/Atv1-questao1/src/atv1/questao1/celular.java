package atv1.questao1;

public class celular {
    //cada celular contem todos esses componentes
    private processador prc;
    private sistema_de_som sis;
    private tela_touch tlt;
    private sistema_de_comunicacao sic;
    
    public celular(int frequencia){
        prc = new processador(frequencia);
        sis = new sistema_de_som("padrao");
        tlt = new tela_touch();
        sic = new sistema_de_comunicacao();
    }
    
    //conecta dispositivo
    public void conecta_dispositivo()  {
        sic.setConectado(true);
    }

    //liga tela
    public void liga_tela() {
        tlt.desliga_inatividade();
    }

    //overclock no processador
    public void overclock() {
        prc.setFrequencia(5200);
    }

    //muda o dispositivo de saida de som para "Fone de ouvido"
    public void coloca_fone() {
        sis.setDispositivo_saida("Fone de ouvido");
    }
}